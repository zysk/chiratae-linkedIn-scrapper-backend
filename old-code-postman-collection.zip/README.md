# LinkedIn Scraper API Postman Collection

This directory contains a Postman collection for the LinkedIn Scraper API, which provides endpoints for managing LinkedIn scraping campaigns, leads, and related data.

## Files

- **collection.json**: Main collection file with common endpoints
- **environment.json**: Environment variables for the collection
- **auth.json**: Authentication-related requests (login, register, etc.)
- **users.json**: User management requests
- **linkedin-accounts.json**: LinkedIn account management requests
- **proxies.json**: Proxy management requests
- **campaigns.json**: Campaign management requests
- **leads.json**: Lead management requests
- **lead-comments.json**: Lead comments management requests
- **lead-logs.json**: Lead logs requests
- **lead-status.json**: Lead status management requests
- **mongodb-samples.json**: Requests to create sample data for testing

## Importing into Postman

1. Open Postman
2. Click on "Import" in the top left
3. Select "Folder" and choose this directory
4. All the collection files will be imported
5. Also import the environment.json file

## Usage Instructions

1. First, set up your environment variables by importing the environment.json file
2. Start by registering an admin user using the "Register Admin" request
3. Login with the admin credentials to get access tokens
4. Use the MongoDB Samples folder to create test data if needed
5. Follow the logical flow of creating LinkedIn accounts, proxies, campaigns, and then leads

## Environment Variables

- **baseUrl**: The base URL for the API (default: http://localhost:4051)
- **adminEmail/adminPassword**: Credentials for admin user
- **accessToken/refreshToken**: Authentication tokens (set automatically after login)
- **userId**: Current user ID (set after login)
- Other IDs for resources like leads, campaigns, etc.

## Authentication Flow

1. Register a user/admin
2. Login to get tokens
3. The tokens will be stored in environment variables
4. Most requests require the Authorization header with the access token

## Creating Sample Data

Use the requests in the MongoDB Samples folder to create test data in this order:
1. Create Admin User
2. Create Regular User
3. Login with either account
4. Create LinkedIn Account
5. Create Proxy
6. Create Campaign
7. Create Lead Status
8. Create Lead
9. Create Lead Comment

## Notes

- Remember to save the environment after getting tokens
- IDs for created resources are automatically saved to environment variables
- Some requests depend on others (e.g., creating a lead requires a campaign ID)

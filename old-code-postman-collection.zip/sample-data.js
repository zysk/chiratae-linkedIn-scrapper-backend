// MongoDB sample data for LinkedIn Scraper API
// Use this script in MongoDB Shell to create sample data

// Connect to database
// mongo mongodb://localhost:27017/linkedInScraper

// Clear existing data
db.users.drop();
db.linkedInAccounts.drop();
db.proxies.drop();
db.campaigns.drop();
db.leads.drop();
db.leadStatuses.drop();
db.leadComments.drop();
db.leadLogs.drop();

// Create admin user
const adminId = ObjectId();
db.users.insertOne({
  _id: adminId,
  name: "Admin User",
  email: "admin@example.com",
  // This is a hashed password for "adminpass123" - in production, use proper hashing
  password: "$2a$10$YQH9sCJDO7U/ZwT8Z1lB7Op4Wil6yBBisBeN4a1yB8vhZJYwYvZte",
  phone: 9876543210,
  role: "ADMIN",
  isActive: true,
  createdAt: new Date(),
  updatedAt: new Date()
});

// Create regular user
const userId = ObjectId();
db.users.insertOne({
  _id: userId,
  name: "Regular User",
  email: "user@example.com",
  // This is a hashed password for "userpass123" - in production, use proper hashing
  password: "$2a$10$X9hCiPYow.B.ZiO7dHKhXeR1bT8VVbhkK3peVHe9sL7QtBCgm7gg6",
  phone: 9876543211,
  role: "USER",
  isActive: true,
  createdAt: new Date(),
  updatedAt: new Date()
});

// Create LinkedIn accounts
const linkedInAccountId = ObjectId();
db.linkedInAccounts.insertOne({
  _id: linkedInAccountId,
  name: "Test LinkedIn Account",
  password: "linkedinpass123",
  clientId: userId.toString(),
  createdAt: new Date(),
  updatedAt: new Date()
});

// Create proxies
const proxyId = ObjectId();
db.proxies.insertOne({
  _id: proxyId,
  value: "http://username:password@proxy-server.com:8080",
  clientId: userId.toString(),
  createdAt: new Date(),
  updatedAt: new Date()
});

// Create lead statuses
db.leadStatuses.insertMany([
  {
    _id: ObjectId(),
    value: "CREATED",
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    _id: ObjectId(),
    value: "CONTACTED",
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    _id: ObjectId(),
    value: "INTERESTED",
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    _id: ObjectId(),
    value: "NOT_INTERESTED",
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    _id: ObjectId(),
    value: "CONVERTED",
    createdAt: new Date(),
    updatedAt: new Date()
  }
]);

// Create campaign
const campaignId = ObjectId();
db.campaigns.insertOne({
  _id: campaignId,
  name: "Sample Search Campaign",
  searchQuery: "Software Engineer",
  accountName: "Test LinkedIn Account",
  proxyId: proxyId.toString(),
  linkedInAccountId: linkedInAccountId.toString(),
  password: "linkedinpass123",
  clientId: userId.toString(),
  company: "Microsoft",
  school: "Stanford",
  location: "United States",
  createdAt: new Date(),
  updatedAt: new Date()
});

// Create leads
const lead1Id = ObjectId();
const lead2Id = ObjectId();

db.leads.insertMany([
  {
    _id: lead1Id,
    clientId: userId.toString(),
    campaignId: campaignId.toString(),
    status: "CREATED",
    rating: "Medium",
    name: "John Doe",
    position: "Software Engineer",
    company: "Microsoft",
    location: "Seattle, Washington, United States",
    linkedinProfileUrl: "https://www.linkedin.com/in/johndoe",
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    _id: lead2Id,
    clientId: userId.toString(),
    campaignId: campaignId.toString(),
    status: "CONTACTED",
    rating: "High",
    name: "Jane Smith",
    position: "Senior Software Engineer",
    company: "Google",
    location: "Mountain View, California, United States",
    linkedinProfileUrl: "https://www.linkedin.com/in/janesmith",
    createdAt: new Date(),
    updatedAt: new Date()
  }
]);

// Create lead comments
db.leadComments.insertMany([
  {
    _id: ObjectId(),
    leadId: lead1Id.toString(),
    createdBy: userId.toString(),
    message: "This lead looks promising, follow up next week.",
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    _id: ObjectId(),
    leadId: lead2Id.toString(),
    createdBy: userId.toString(),
    message: "Had initial discussion, very interested in our product.",
    createdAt: new Date(),
    updatedAt: new Date()
  }
]);

// Create lead logs
db.leadLogs.insertMany([
  {
    _id: ObjectId(),
    leadId: lead1Id.toString(),
    action: "STATUS_CHANGE",
    prevValue: null,
    newValue: "CREATED",
    performedBy: userId.toString(),
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    _id: ObjectId(),
    leadId: lead2Id.toString(),
    action: "STATUS_CHANGE",
    prevValue: "CREATED",
    newValue: "CONTACTED",
    performedBy: userId.toString(),
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    _id: ObjectId(),
    leadId: lead2Id.toString(),
    action: "RATING_CHANGE",
    prevValue: "Medium",
    newValue: "High",
    performedBy: userId.toString(),
    createdAt: new Date(),
    updatedAt: new Date()
  }
]);

print("Sample data created successfully!");
print("Admin user: admin@example.com / adminpass123");
print("Regular user: user@example.com / userpass123");
print("LinkedIn Account ID: " + linkedInAccountId.toString());
print("Proxy ID: " + proxyId.toString());
print("Campaign ID: " + campaignId.toString());
print("Lead IDs: " + lead1Id.toString() + ", " + lead2Id.toString());

# Importing the LinkedIn Scraper API Collection into Postman

This guide explains how to import the LinkedIn Scraper API collection into Postman.

## Method 1: Using Postman UI

1. **Open Postman**
2. **Click on "Import" in the top-left corner**
3. **Select "Folder" tab**
4. **Click "Choose Folders" and select the `collections` directory**
5. **Select all JSON files and click "Import"**
6. **Import the environment separately:**
   - Go to the Environments tab (in the left sidebar)
   - Click the "Import" button
   - Select the `environment.json` file

## Method 2: Using Postman CLI (Newman)

If you prefer command line:

1. **Install Newman (Postman CLI):**
   ```bash
   npm install -g newman
   ```

2. **Run the collection:**
   ```bash
   newman run collections/collection.json -e collections/environment.json
   ```

## Setting Up Environment Variables

After importing:

1. **Select the "LinkedIn Scraper API" environment** from the environment dropdown in the top-right corner
2. **Edit the environment variables** if needed (e.g., change the baseUrl if your API runs on a different port)
3. **Save the environment**

## Creating Test Data Using MongoDB Sample Script

1. **Start MongoDB shell:**
   ```bash
   mongo mongodb://localhost:27017/linkedInScraper
   ```

2. **Copy and paste the content** from `sample-data.js` into the MongoDB shell
3. **Execute the script** to create all sample data
4. **Note the IDs** displayed in the output - you'll need these for testing

## Workflow For Testing

1. **Login using the Admin or User credentials** from the sample data
   - Admin: admin@example.com / adminpass123
   - User: user@example.com / userpass123

2. **The login request will automatically set** the `accessToken` and `refreshToken` variables

3. **Set other environment variables manually:**
   - Copy the IDs from the MongoDB script output
   - Set them in the appropriate environment variables:
     - userId
     - linkedInAccountId
     - proxyId
     - campaignId
     - leadId

4. **Start testing the endpoints** following the logical flow of the application

## Collection Structure

The collection is organized into logical folders:

- **Authentication**: User registration, login, token refresh
- **Users**: User management endpoints
- **LinkedIn Accounts**: LinkedIn account creation and management
- **Proxies**: Proxy management for LinkedIn scraping
- **Campaigns**: LinkedIn scraping campaign management
- **Leads**: Lead management and manipulation
- **Lead Comments**: Comments on leads
- **Lead Logs**: Activity logs for leads
- **Lead Status**: Status management for leads
- **MongoDB Samples**: Sample data creation requests

## Notes

- Remember to include the Authorization header (Bearer token) for protected endpoints
- Some requests depend on others having been executed first
- The environment variables are used to store IDs and tokens between requests

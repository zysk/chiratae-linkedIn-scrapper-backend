// Script to build a consolidated Postman collection from individual JSON files
const fs = require('fs');
const path = require('path');

// Files to include
const files = [
  'auth.json',
  'users.json',
  'linkedin-accounts.json',
  'proxies.json',
  'campaigns.json',
  'leads.json',
  'lead-comments.json',
  'lead-logs.json',
  'lead-status.json',
  'mongodb-samples.json'
];

// Base collection structure
const collection = {
  "info": {
    "name": "LinkedIn Scraper API",
    "description": "API collection for LinkedIn scraping and lead management system",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "item": [
    {
      "name": "API Info",
      "description": "Overview of the API",
      "item": [
        {
          "name": "API Info",
          "request": {
            "method": "GET",
            "header": [],
            "url": "{{baseUrl}}/",
            "description": "Get API information"
          },
          "response": []
        },
        {
          "name": "Health Check",
          "request": {
            "method": "GET",
            "header": [],
            "url": "{{baseUrl}}/api/health",
            "description": "Check if the API is running"
          },
          "response": []
        }
      ]
    }
  ]
};

// Add each file's content to the collection
files.forEach(file => {
  try {
    const content = JSON.parse(fs.readFileSync(path.join(__dirname, file), 'utf8'));
    collection.item.push(content);
  } catch (err) {
    console.error(`Error processing ${file}:`, err.message);
  }
});

// Write the consolidated collection to a file
fs.writeFileSync(
  path.join(__dirname, 'linkedin-scraper-api-collection.json'),
  JSON.stringify(collection, null, 2),
  'utf8'
);

console.log('Collection built successfully: linkedin-scraper-api-collection.json');

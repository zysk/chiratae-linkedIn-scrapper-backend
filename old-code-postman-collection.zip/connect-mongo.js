// MongoDB connection script for LinkedIn Scraper API
// Use this script to test your MongoDB connection

const { MongoClient } = require('mongodb');

// Connection URL and Database Name
const url = 'mongodb://localhost:27017';
const dbName = 'linkedInScraper';

async function main() {
  console.log('Attempting to connect to MongoDB...');

  const client = new MongoClient(url, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  });

  try {
    // Connect to the MongoDB server
    await client.connect();
    console.log('✅ Successfully connected to MongoDB server');

    // Connect to the database
    const db = client.db(dbName);
    console.log(`✅ Connected to database: ${dbName}`);

    // List collections
    const collections = await db.listCollections().toArray();
    console.log('\nAvailable collections:');
    collections.forEach(collection => {
      console.log(`- ${collection.name}`);
    });

    // Count documents in each collection
    console.log('\nDocument counts:');
    for (const collection of collections) {
      const count = await db.collection(collection.name).countDocuments();
      console.log(`- ${collection.name}: ${count} documents`);
    }

    // Check if required collections exist
    const requiredCollections = [
      'users',
      'linkedInAccounts',
      'proxies',
      'campaigns',
      'leads',
      'leadStatuses',
      'leadComments',
      'leadLogs'
    ];

    const missingCollections = requiredCollections.filter(
      name => !collections.some(col => col.name === name)
    );

    if (missingCollections.length > 0) {
      console.log('\n⚠️ Missing collections:');
      missingCollections.forEach(name => console.log(`- ${name}`));
      console.log('\nRun the sample-data.js script to create these collections.');
    } else {
      console.log('\n✅ All required collections exist!');
    }

    // Check if there's an admin user
    const adminUser = await db.collection('users').findOne({ role: 'ADMIN' });
    if (adminUser) {
      console.log(`\n✅ Admin user found: ${adminUser.email}`);
    } else {
      console.log('\n⚠️ No admin user found. Run the sample-data.js script to create one.');
    }

  } catch (err) {
    console.error('❌ Error connecting to MongoDB:', err);
  } finally {
    await client.close();
    console.log('\nConnection closed');
  }
}

main().catch(console.error);
